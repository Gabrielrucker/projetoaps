function mudaImagem(imagem)
{
	document.getElementById('icone').src = imagem;
}